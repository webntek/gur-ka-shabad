//
//  cell.swift
//  Gur Ka Shabad
//
//  Created by Admin on 22/09/18.
//  Copyright © 2018 anamcorp. All rights reserved.
//

import UIKit

class cell: UITableViewCell {

    @IBOutlet weak var punjabiTxt: UILabel!
    @IBOutlet weak var englishTxt: UILabel!
    @IBOutlet weak var punjabiMeaningTxt: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
